/*
 * File: Yahtzee.java
 * ------------------
 * This program will eventually play the Yahtzee game.
 */

import java.util.*;
import acm.io.*;
import acm.program.*;
import acm.util.*;

public class Yahtzee extends GraphicsProgram implements YahtzeeConstants {

	/**
	 *
	 */
	private static final long serialVersionUID = 2733144457731908158L;
	public static void main(String[] args) {
		new Yahtzee().start(args);
	}
	public void run() {
		IODialog dialog = getDialog();
		nPlayers = dialog.readInt("Enter number of players");
		playerNames = new String[nPlayers];
		for (int i = 1; i <= nPlayers; i++) {
			playerNames[i - 1] = dialog.readLine("Enter name for player " + i);
		}
		display = new YahtzeeDisplay(getGCanvas(), playerNames);
		playGame();
	}

	private void playGame() {
		score = new int [nPlayers+1][N_CATEGORIES+1];
		for(int round = 0; round < 13;){
			display.printMessage("Round: "+ ++round);
			for(int player = 1; player<=nPlayers; player++){
				display.printMessage(playerNames[player-1] + "'s turn!");
				int turn = 0;
				while(turn <= 2){
					if (turn == 0)
						display.waitForPlayerToClickRoll(player);
					else
						display.waitForPlayerToSelectDice();
					dice = rollDice(dice, rgen, turn);
					display.displayDice(dice);
					turn++;
				}
				int cat;
				while(true){
					cat = display.waitForPlayerToSelectCategory();
					if (checkCategory(dice, cat))
						break;
				}

				score[player][cat] = calcScore(cat,dice);
				display.updateScorecard(cat, player,score[player][cat]);


				score[player][UPPER_SCORE] = score[player][ONES] + score[player][TWOS] + score[player][THREES]
											+ score[player][FOURS] + score[player][FIVES] + score[player][SIXES] ;
				display.updateScorecard(UPPER_SCORE, player, score[player][UPPER_SCORE]);


				if(score[player][UPPER_SCORE] >= 63)
					score[player][UPPER_BONUS] = 35;
				else
					score[player][UPPER_SCORE] = 0;
				display.updateScorecard(UPPER_BONUS, player, score[player][UPPER_BONUS]);


				score[player][LOWER_SCORE] = score[player][THREE_OF_A_KIND] + score[player][FOUR_OF_A_KIND]
											+ score[player][FULL_HOUSE]	+ score[player][LARGE_STRAIGHT]
											+ score[player][SMALL_STRAIGHT]	+ score[player][YAHTZEE]
											+ score[player][CHANCE];
				display.updateScorecard(LOWER_SCORE, player, score[player][LOWER_SCORE]);



				score[player][TOTAL] = score[player][UPPER_SCORE] + score[player][UPPER_BONUS]
										+ score[player][LOWER_SCORE];
				display.updateScorecard(TOTAL, player, score[player][TOTAL]);

			}
		}
	}

	private boolean checkCategory(int [] dice, int cat){

		ArrayList<Integer> dArray = new ArrayList<Integer>();

		for(int i : dice)
			dArray.add(i);

		Collections.sort(dArray);

		switch (cat) {
			case CHANCE:
			case SIXES:
			case FIVES:
			case FOURS:
			case THREES:
			case TWOS:
			case ONES:
				return true;

			case THREE_OF_A_KIND:
				return check3K(dArray);

			case FOUR_OF_A_KIND:
				return check4K(dArray);

			case FULL_HOUSE:
				return checkFH(dArray);

			case YAHTZEE:
				return checkYz(dArray);

			case SMALL_STRAIGHT:
				return checkSSt(dArray);

			case LARGE_STRAIGHT:
				return checkLSt(dArray);
		}
		return false;

	}

	private boolean check3K(ArrayList<Integer> dArray) {
		int count = 0;
		int i = 0;
		while(i<dArray.size()-1){
			if (dArray.get(i)==dArray.get(++i))
				count++;
			else
				count = 0;
			if (count>=2)
				return true;
		}
		return false;
	}

	private boolean check4K(ArrayList<Integer> dArray) {

		ArrayList<Integer> dCopy = new ArrayList<>(dArray);
		ArrayList<Integer> dCopy2 = new ArrayList<>(dArray);
		dCopy.remove(0); dCopy2.remove(4);
		if (checkYz(dCopy)||checkYz(dCopy2))
			return true;
		return false;
	}

	private boolean checkFH(ArrayList<Integer> dArray){
		if ((dArray.get(0)==dArray.get(1))
				&& (dArray.get(1) == dArray.get(2))
				&& (dArray.get(2) != dArray.get(3))
				&& (dArray.get(3) == dArray.get(4))
				)
			return true;

		if ((dArray.get(2)==dArray.get(3))
				&& (dArray.get(3) == dArray.get(4))
				&& (dArray.get(2) != dArray.get(0))
				&& (dArray.get(0) == dArray.get(1))
				)
			return true;
		return false;
	}

	private boolean checkYz(ArrayList<Integer> dArray) {
		int x=dArray.get(0);
		for (int i : dArray) {
			if (x != i)
				return false;
		}
		return true;
	}

	private boolean checkSSt(ArrayList<Integer> dArray) {

		if (removeReps(dArray))
			return checkLSt(dArray);
		else {
			ArrayList<Integer> dCopy = new ArrayList<Integer>(dArray);
			dCopy.remove(0);
			if (checkLSt(dCopy))
				return true;
			dCopy = new ArrayList<Integer>(dArray);
			dCopy.remove(4);
			if (checkLSt(dCopy))
				return true;
		}
		return false;

	}

	private boolean removeReps(ArrayList<Integer> dArray) {
		for(int i=0;i<dArray.size()-1;){
			if((dArray.get(i)).equals(dArray.get(++i))) {
				dArray.remove(i);
				return true;
			}
		}
		return false;
	}

	private boolean checkLSt(ArrayList<Integer> dArray) {
		for(int i=0;i<dArray.size()-1;){
			if((dArray.get(i)+1)!=dArray.get(++i))
				return false;
		}
		return true;
	}


	private int calcScore(int cat, int[] dice) {

		if (cat>=ONES && cat <= SIXES)
			return sum(cat,dice);

		if (cat == THREE_OF_A_KIND || cat == FOUR_OF_A_KIND || cat == CHANCE)
			return sum(dice);

		switch (cat) {
		case FULL_HOUSE:
			return 25;
		case SMALL_STRAIGHT:
			return 30;
		case LARGE_STRAIGHT:
			return 40;
		case YAHTZEE:
			return 50;

		default:
			return 0;
		}

	}
	private int sum(int[] dice) {
		int sum = 0;
		for(int e:dice){
			sum += e;
		}
		return sum;
	}

	private int sum(int cat, int dice[]) {
		int sum = 0;
		for(int e:dice){
			if (e == cat)
				sum += e;
		}
		return sum;
	}

	private int[] rollDice(int dice[], RandomGenerator rgen, int turn) {
		for(int i=0;i<dice.length;i++){
			if ((turn == 0) || (display.isDieSelected(i))){
				dice[i]= rgen.nextInt(1,6);
			}
		}
		return dice;
	}






	/* Private instance variables */
	private int nPlayers;
	private int score[][];
	private int dice[] = new int[N_DICE];
	private String[] playerNames;
	private YahtzeeDisplay display;
	private RandomGenerator rgen = new RandomGenerator();

}