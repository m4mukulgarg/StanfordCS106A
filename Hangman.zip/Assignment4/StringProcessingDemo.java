import acm.program.*;

public class StringProcessingDemo extends ConsoleProgram{
		
	public void run(){
		while(true){
			String digits = readLine("Enter a numeric string: ");
			if (digits.length() == 0) break;
			println(addCommasToNumericString(digits));
		}
		println(removeAll("This is a test", 't'));
		println(removeAll("Summer is here", 'e'));
		println(removeAll("---0---", '-'));
		int x = 13/1%2;
		println(x);
	}

	private String removeAll(String string, char c) {
		String result = "";
		for(int i = 0; i < string.length(); i++)
			if (string.charAt(i) != c) result += Character.toString(string.charAt(i)); 
		
		return result;
	}

	private String addCommasToNumericString(String digits) {
		if (digits.length() <=3) return digits;
		String result = "";
		for(int i = digits.length(); i>0; i--){
			result = digits.charAt(digits.length()-i-1) + result;
			if ((((i)%3) == 0) && (i >0))result = "," + result;
		}
		return result;
	}
}
