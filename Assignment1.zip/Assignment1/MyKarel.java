import stanford.karel.*;


public abstract class MyKarel extends SuperKarel {
	void faceSouth(){
		while(!facingSouth())
			turnLeft();
	}
	
	void faceEast(){
		while(!facingEast())
			turnLeft();
	}
	
	void faceNorth(){
		while(!facingNorth())
			turnLeft();
	}
	
	void faceWest(){
		while(!facingWest())
			turnLeft();
	}
	public abstract void  run();
}
