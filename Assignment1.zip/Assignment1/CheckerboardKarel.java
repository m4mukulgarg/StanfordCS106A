

public class CheckerboardKarel extends MyKarel {
	public boolean lastIsFilled = false; 
	
	public void fillCorner(){
		if (!lastIsFilled){
			//lastIsFilled=!lastIsFilled;
			putBeeper();
		}
	}
	
	public void fillRow(){
		
		while(true){
			fillCorner();
			if (frontIsClear()){
				move();
				lastIsFilled=!lastIsFilled;
				continue;
			}
			if (frontIsBlocked()){
				if(facingEast() && leftIsClear()){
					//fillCorner();
					moveUpFaceWest();
					continue;
				}
				else if(facingWest()&& rightIsClear()){
					moveUpFaceEast();
					continue;
				}
				else {
					lastIsFilled = false;
					break;
				}
			}
		}
	}
	
	public void moveUpFaceWest(){
		faceNorth();
		move();
		lastIsFilled = !lastIsFilled;
		faceWest();
	}
	
	public void moveUpFaceEast(){
		faceNorth();
		move();
		lastIsFilled = !lastIsFilled;
		faceEast();
	}

	public void run() {
       fillRow();
	}
}