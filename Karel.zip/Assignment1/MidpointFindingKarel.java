
public class MidpointFindingKarel extends MyKarel {

	public void fillRow(){
		while(true){
			putBeeper();
			if (frontIsBlocked()){
				break;
			}
			move();
		}
	}
	
	public void pickBeeperOnWest(){
		faceWest();
		while(frontIsClear()) move();
		faceEast();
		while(noBeepersPresent())move();
		pickBeeper();
		faceWest();	
	}
	
	public void pickBeeperOnEast(){
		faceEast();
		while(frontIsClear()) move();
		faceWest();
		while(noBeepersPresent())move();
		pickBeeper();
		faceEast();	
	}
	
	public boolean notLastBeeper(){
	
		turnAround();
		move();
	
		if (beepersPresent()){
			turnAround();
			move();
			return true;
		}
		else {
			turnAround();
			move();
			return false;
		}
	}
	
	public void run(){
		fillRow();
//		while(true){
//			if (noBeepersPresent()){
//				putBeeper();
//				break;
//			}
		while(notLastBeeper()){
			if (facingEast()) pickBeeperOnWest();
			else if (facingWest()) pickBeeperOnEast();
		}
		putBeeper();
		faceEast();
//		pickBeeperOnWest();
//		pickBeeperOnEast();
//		pickBeeperOnWest();
//		pickBeeperOnEast();
//		pickBeeperOnWest();
//		pickBeeperOnEast();
//		
		}
}
