
public class KarelDefendsDemocracy extends stanford.karel.SuperKarel {
	
	public void clearChad(){
		setDirection(0);
		move();
		while(beepersPresent()) pickBeeper();
		turnAround();
		move();move();
		while(beepersPresent()) pickBeeper();
		turnAround();
		move();
		setDirection(1);
	}
	
	
	public void run(){

		while(frontIsClear()){
			move();
			if(noBeepersPresent()){
				clearChad();
			}
			move();
		}
	}
}
