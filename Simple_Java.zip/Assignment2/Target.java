/*
 * File: Target.java
 * Name: 
 * Section Leader: 
 * -----------------
 * This file is the starter file for the Target problem.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Target extends GraphicsProgram {	

	/**
	 * 
	 */
	private static final long serialVersionUID = 5705336058370269464L;

	/** Value of  one inch in pixels */
	public static final double INCH = 72.00;

	/** Radius of outermost circle, painted red, in pixels */
	public static final double OUTER_RADIUS = INCH;
	
	/** Radius of middle circle, painted white, in pixels */
	public static final double MID_RADIUS = INCH*0.65;
	
	/** Radius of innermost circle, painted red, in pixels */
	public static final double INNER_RADIUS = INCH*0.3;

	public void run() {
		
		GOval outer = new GOval(getWidth()/2-OUTER_RADIUS/2,getHeight()/2-OUTER_RADIUS/2,OUTER_RADIUS,OUTER_RADIUS);
		outer.setFilled(true);outer.setFillColor(Color.RED);
		GOval mid = new GOval(getWidth()/2-MID_RADIUS/2,getHeight()/2-MID_RADIUS/2,MID_RADIUS,MID_RADIUS);
		mid.setFilled(true);mid.setFillColor(Color.WHITE);
		GOval inner = new GOval(getWidth()/2-INNER_RADIUS/2,getHeight()/2-INNER_RADIUS/2,INNER_RADIUS,INNER_RADIUS);
		inner.setFilled(true);inner.setFillColor(Color.RED);
		add(outer);
		add(mid);
		add(inner);	
	}
}
