import acm.program.*;

public class FibonacciSeries extends ConsoleProgram{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7231418152702436986L;

	public void run(){
		/** Limiting value. */
		final int MAX_VALUE = 10000;
//		int m = 0;
		int n = 1;
		int term=n;
		println (0+"\n"+1);
		while(term < MAX_VALUE){
			println(term);
			int m=term;
			term+=n;
			n=m;
			//println(term);
		}
	}
}
