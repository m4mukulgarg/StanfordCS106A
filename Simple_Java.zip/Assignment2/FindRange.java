/*
 * File: FindRange.java
 * Name: 
 * Section Leader: 
 * --------------------
 * This file is the starter file for the FindRange problem.
 */

import acm.program.*;

public class FindRange extends ConsoleProgram {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5995814078277545505L;

	private static final int SENTINEL = 0;
	private static int large = 0, small = 0;
	private static int input = 0;
	
	public void run() {
	
		println("This program finds the largest and smallest numbers.");
		while(true){
			input = readInt();
			if (input==SENTINEL)
				break; 
			if ((large==0)||(input>large)) large = input;
			if ((small==0)||(input<small)) small = input;	
		}
		if (large == 0)
			println("No value entered.");
		else{
			println("largest:\t" + large);
			println("smallest:\t" + small);
		}
	}
}

