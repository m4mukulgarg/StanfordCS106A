/*
 * File: PythagoreanTheorem.java
 * Name: 
 * Section Leader: 
 * -----------------------------
 * This file is the starter file for the PythagoreanTheorem problem.
 */

import acm.program.*;

public class PythagoreanTheorem extends ConsoleProgram {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5935443931329962704L;

	public void run() {
		int a,b;
		double c;
		println("Enter values to compute pythagorean theorem.");
		print("a:\t");
		a = readInt();
		print("b:\t");
		b = readInt();
		c = Math.sqrt(a*a+b*b);
		println(c);
	}
}
