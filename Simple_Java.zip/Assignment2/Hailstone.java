/*
 * File: Hailstone.java
 * Name: 
 * Section Leader: 
 * --------------------
 * This file is the starter file for the Hailstone problem.
 */

import acm.program.*;

public class Hailstone extends ConsoleProgram {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2384864848503218968L;

	public void run() {
		println("Enter a number:\t");
		int n = readInt(); 
		/**count the number of steps. */
		int count = 0;
		while(n>1){
			/** n is even */
			if (n%2==0){
				print(n + " is even, so I take half: ");
				n = n/2;
				println(n);
				count++;
			}
			/** n is odd */
			else{
				print(n + " is odd, so I take 3n+1: ");
				n = 3*n+1;
				println(n);
				count++;
			}
		}
		println("The process took "+ count +" to reach 1"); 
	}
}