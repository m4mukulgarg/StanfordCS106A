import acm.graphics.*;
import acm.program.*;

public class RobotFace extends GraphicsProgram {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7489531748053730220L;

	private static final int HEAD_WIDTH = 200;
	private static final int HEAD_HEIGHT = 300;
	private static final int EYE_RADIUS = 15;
	private static final int MOUTH_WIDTH = 100;
	private static final int MOUTH_HEIGHT = 60;
	public void run(){
		GRect head = new GRect((getWidth()-HEAD_WIDTH)/2,(getHeight()-HEAD_HEIGHT)/2,HEAD_WIDTH,HEAD_HEIGHT);
		head.setFillColor(java.awt.Color.GRAY);
		head.setFilled(true);
		add(head);
		GOval eyeLeft = new GOval(head.getX()+HEAD_WIDTH/4-EYE_RADIUS,head.getY()+HEAD_HEIGHT/4-EYE_RADIUS,EYE_RADIUS*2,EYE_RADIUS*2);
		eyeLeft.setFillColor(java.awt.Color.YELLOW);
		eyeLeft.setFilled(true);
		add(eyeLeft);
		GOval eyeRight = new GOval(head.getX()+HEAD_WIDTH*3/4-EYE_RADIUS,head.getY()+HEAD_HEIGHT/4-EYE_RADIUS,EYE_RADIUS*2,EYE_RADIUS*2);
		eyeRight.setFillColor(java.awt.Color.YELLOW);
		eyeRight.setFilled(true);
		add(eyeRight);
		GRect mouth = new GRect(head.getX()+(HEAD_WIDTH-MOUTH_WIDTH)/2,head.getY()+(HEAD_HEIGHT*3/4)-MOUTH_HEIGHT,MOUTH_WIDTH,MOUTH_HEIGHT);
		mouth.setFillColor(java.awt.Color.WHITE);
		mouth.setFilled(true);		
		add(mouth);
	}
}
