/*
 * File: ProgramHierarchy.java
 * Name: 
 * Section Leader: 
 * ---------------------------
 * This file is the starter file for the ProgramHierarchy problem.
 */

import acm.graphics.*;
import acm.program.*;

public class ProgramHierarchy extends GraphicsProgram {	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** Length of the rectangles. */
	public final double RECT_LEN = 72*2;
	/** Breadth of the rectangles. */
	public final double RECT_BR = 24*2;
	
	public void run() {
		/* You fill this in. */
		
		GRect rect1 =  new GRect((getWidth()-RECT_LEN)/2,(getHeight()-(3*RECT_BR))/2,RECT_LEN,RECT_BR);
		GLabel label1 = new GLabel("Program");
		label1.setLocation((rect1.getX()+(rect1.getWidth()-label1.getWidth())/2), (rect1.getY()+rect1.getHeight()-(rect1.getHeight()-label1.getAscent())/2));
		add(rect1);
		add(label1);

		GRect rect2 =  new GRect((getWidth()-3*RECT_LEN-RECT_BR)/2,(getHeight()+RECT_BR)/2,RECT_LEN,RECT_BR);
		GLabel label2 = new GLabel("GraphicsProgram");
		label2.setLocation((rect2.getX()+(rect2.getWidth()-label2.getWidth())/2), (rect2.getY()+rect2.getHeight()-(rect2.getHeight()-label2.getAscent())/2));
		add(rect2);
		add(label2);
		
		GRect rect3 =  new GRect((getWidth()-RECT_LEN)/2,(getHeight()+RECT_BR)/2,RECT_LEN,RECT_BR);
		GLabel label3 = new GLabel("ConsoleProgram");
		label3.setLocation((rect3.getX()+(rect3.getWidth()-label3.getWidth())/2), (rect3.getY()+rect3.getHeight()-(rect3.getHeight()-label3.getAscent())/2));
		add(rect3);
		add(label3);
		
		GRect rect4 =  new GRect((getWidth()+RECT_LEN+RECT_BR)/2,(getHeight()+RECT_BR)/2,RECT_LEN,RECT_BR);
		GLabel label4 = new GLabel("DialogProgram");
		label4.setLocation((rect4.getX()+(rect4.getWidth()-label4.getWidth())/2), (rect4.getY()+rect4.getHeight()-(rect4.getHeight()-label4.getAscent())/2));
		add(rect4);
		add(label4);
		
		add(new GLine(rect1.getX()+rect1.getWidth()/2, rect1.getY()+rect1.getHeight(), rect2.getX()+rect2.getWidth()/2, rect2.getY()));
		add(new GLine(rect1.getX()+rect1.getWidth()/2, rect1.getY()+rect1.getHeight(), rect3.getX()+rect3.getWidth()/2, rect3.getY()));
		add(new GLine(rect1.getX()+rect1.getWidth()/2, rect1.getY()+rect1.getHeight(), rect4.getX()+rect4.getWidth()/2, rect4.getY()));
	}
}
