


/**
 * A class of freshmen students only.
 * @author WantedChamp
 */
public class Frosh extends Student {
	
	/** Constructor. Sets earned units to 0.
	 * @param name	Name of the student. 
	 * @param id	Student id of student.
	 */
	public Frosh (String name, int id){
		super(name,id);
		setUnits(0);
	}
	
	/** @return Student name and id in String format.*/
	public String toString(){
		return "Frosh: " + super.toString() ;
	}

}
