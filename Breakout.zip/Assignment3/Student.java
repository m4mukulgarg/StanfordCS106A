

/** 
 * The Student objects hold information regarding
 * a student. 
 * @author Garg, M.
 */
public class Student {
	
	/** 
	 * Constructor
	 * @param name	Name of the student. 
	 * @param id	Student id of student.
	 */
	public Student (String name, int id){
		studName = name;
		studId = id;
	}
	
	/** 
	 * Gets the name of this Student.
	 * @return Name of the student.
	 */
	public String getName(){
		return studName;
	}
	
	/**
	 * Gets the id of this student.  
	 * @return Id of the student.
	 */
	public int getId(){
		return studId;
	}
	
	/**
	 * Gets the no. of units earned by this student.
	 * @return Units earned.
	 */
	 public double getUnits(){
		return unitsEarned;
	}
	
	/**
	 * Sets the no. of units for this student.
	 * @param units Value of units earned.*/
	public void setUnits(double units){
		unitsEarned = units;
	}
	
	/**
	 * Increments the no. of units earned.
	 * @param additionalUnits Additional no. of units earned.
	 */
	public void incrementUnits(double additionalUnits){
		unitsEarned += additionalUnits;
	}
	
	/** 
	 * Checks the no. of units earned.
	 * @return Whether the student has enough units to graduate.
	 */
	public boolean hasEnoughUnits(){
		return unitsEarned >= _UNITS_TO_GRADUATE;
	}
	
	/** 
	 * Creates a String identifying the student.
	 * @return The String used to identify this Student
	 */
	public String toString(){
		return studName + "(#" + studId + ")" ;
	}
	
	/** No. of units required by each student to
	 *  graduate. */
	public static final double _UNITS_TO_GRADUATE = 180.00;
	
	/** Name of student.*/
	private String studName;
	
	/** Unique id of student.*/
	private int studId;
	
	/** Units earned by student so far.*/
	private double unitsEarned;
}
