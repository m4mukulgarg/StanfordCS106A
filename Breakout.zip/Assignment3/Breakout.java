/*
 * File: Breakout.java
 * -------------------
 * Name:
 * Section Leader:
 * 
 * This file will eventually implement the game of Breakout.
 */

import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.awt.*;
import java.awt.event.*;

public class Breakout extends GraphicsProgram {

	/** Width of application window in pixels */
	public static final int APPLICATION_WIDTH = 400;
	
	/** Height of application window in pixels */
	public static final int APPLICATION_HEIGHT = 600;

	/** Width of game board.*/
	private static final int WIDTH = APPLICATION_WIDTH;
	
	/** Height of game board.*/
	private static final int HEIGHT = APPLICATION_HEIGHT;

	/** Dimensions of the paddle */
	private static final int PADDLE_WIDTH = 60, PADDLE_HEIGHT = 10;;

	/** Offset of the paddle up from the bottom */
	private static final int PADDLE_Y_OFFSET = 30;

	/** Number of bricks per row */
	private static final int NBRICKS_PER_ROW = 10;

	/** Number of rows of bricks */
	private static final int NBRICK_ROWS = 10;

	/** Separation between bricks */
	private static final int BRICK_SEP = 4;

	/** Width of a brick */
	private static final int BRICK_WIDTH =
	  (WIDTH - (NBRICKS_PER_ROW - 1) * BRICK_SEP) / NBRICKS_PER_ROW;

	/** Height of a brick */
	private static final int BRICK_HEIGHT = 8;

	/** Radius of the ball in pixels */
	private static final int BALL_RADIUS = 10;

	/** Offset of the top brick row from the top */
	private static final int BRICK_Y_OFFSET = 70;

	/** Offset of the left brick column from the left */
	private static final int BRICK_X_OFFSET = (WIDTH - ((BRICK_WIDTH * NBRICKS_PER_ROW) +( BRICK_SEP * (NBRICKS_PER_ROW - 1))))/2;

	/** Number of turns */
	private static final int NTURNS = 3;
	
	/** x-coordinate of the paddle (centered)*/
	private static int paddleX = (WIDTH - PADDLE_WIDTH)/2;
	
	/** x-coordinate of the paddle (centered)*/
	private static final int PADDLE_Y = (HEIGHT - PADDLE_Y_OFFSET - PADDLE_HEIGHT);
	
	/** Paddle.*/
	private static GRect paddle = new GRect (paddleX, PADDLE_Y, PADDLE_WIDTH, PADDLE_HEIGHT);
	
	/** Lower bound of the ball. */
	private static final int BALL_Y_MAX = (PADDLE_Y - (BALL_RADIUS*2));
	
	/** Ball.*/
	private static GOval ball = new GOval (2*BALL_RADIUS,2*BALL_RADIUS);
	
	/** Velocity of the ball in vertical direction.*/
	private static double vy = 0.0;
	
	/** Velocity of the ball in horizontal direction.*/
	private static double vx = 0.0;
	
	/** Current colliding object.*/
	private static GObject collider = null;
	
	/** Specify whether the turn ends.*/
	private static boolean endTurn = false;
	
	/** Specifies whether the ball is mounted on paddle or not.*/
	private static boolean ballMounted = true;
	
	/** Instantaneous amount of bricks present.*/
	private static int brickCounter = 0;
	
	
	/* Method: run() */
	/** Runs the Breakout program. */
	public void run() {
		setup();
		addMouseListeners();
		
		/* The game runs for NTURNS times.*/
		for(int i = 0; i<NTURNS; i++){	
			endTurn = false;
			vx = RandomGenerator.getInstance().nextDouble(1.0,3.0);
			if (RandomGenerator.getInstance().nextBoolean(0.5)) invertX();
			vy = -3;
			waitForClick();
			ballMounted = false;
			while (true){
				if (brickCounter == 0){
					add(new GLabel("YOU WIN"));
					exit();
				}
				moveBall();
				checkForCollisions();
				if (endTurn) break;
				pause(10);
			}
		}
	}
	
	/** 
	 * Move the paddle along x-axis with respect to the mouse.
	 * If the turn is yet to be started, moves the ball along with the paddle.
	 */
	public void mouseMoved(MouseEvent e){
		if((e.getX() < (WIDTH-PADDLE_WIDTH/2)) && (e.getX() > (PADDLE_WIDTH/2))){
			paddleX = e.getX() - (int)paddle.getWidth()/2;
			paddle.setLocation(paddleX, PADDLE_Y);
			paddle.setFilled(true);
			paddle.setFillColor(RandomGenerator.getInstance().nextColor());
			paddle.setColor(RandomGenerator.getInstance().nextColor());
		}
		if (ballMounted) setupBall() ;
	}
	
	
	/** Moves the ball vx pixels horizontally and vy pixels vertically.*/ 
	public void moveBall(){
		ball.move(vx,vy);
	}
	
	/** Checks the ball for collisions and bounces appropriately.*/ 
	public void checkForCollisions() {
		
		/* If collided with the left wall...*/
		if (ball.getX() <= 0)  invertX();
		
		/* If collided with the right wall...*/
		else if (ball.getX()+2*BALL_RADIUS >= WIDTH) invertX();
		else {
			/* Checks to see if colliding with a GObject.*/
			collider = getCollidingObject();
			
			/* If collided with the paddle...*/
			if (collider == paddle){
				invertY();
				ball.setFillColor(collider.getColor());
			}
			
			/* If collided with something other than the paddle, i.e., a brick...*/
			else if (collider != null){
				invertY();
				ball.setFillColor(collider.getColor());
				brickCounter--;
				remove(collider);
			}
		}
		
		/* if collided with the lower wall, ends turn...*/
		if ((ball.getY()+BALL_RADIUS*2) > HEIGHT) {
			endTurn = true;
			setupPaddle();
			ballMounted = true;
			setupBall();
		}
		
		/*If collided with the upper wall...*/
		if (ball.getY() == 0) invertY();
	}
	
	/**
	 * Checks if the ball has collided with an object.
	 * @return collider An object with which the ball has collided.
	 */
	private GObject getCollidingObject() {
		GObject collider = null;
		if (collider != null) return collider;
		else{
			collider = getElementAt(ball.getX()+BALL_RADIUS*2,ball.getY());
			if (collider != null) return collider;
			else{
				collider = getElementAt(ball.getX()+BALL_RADIUS*2,ball.getY()+BALL_RADIUS*2);
				if (collider != null) return collider;
				else{
					collider = getElementAt(ball.getX(),ball.getY()+BALL_RADIUS*2);
					return collider;
				}
			}
		}
	}
				
	/** Changes the direction of horizontal velocity.*/
	private void invertX() {
		vx = -vx;
	}
	
	/** Changes the direction of vertical velocity.*/
	private void invertY() {
		vy = -vy;
	}

	/** Builds the wall of bricks and creates the paddle.*/
	public void setup(){
		/*Set up the paddle.*/
		setupPaddle();
		
		/*Creating the bricks.*/
		/** Coordinates of current brick.*/
		int brickX = BRICK_X_OFFSET, brickY = BRICK_Y_OFFSET;
		
		for(int i = 0; i < NBRICK_ROWS; i++){		
			Color c = null;
			if (i <=1) c = Color.RED;
			else if (i<=3) c = Color.ORANGE;
			else if (i<=5) c = Color.YELLOW;
			else if (i<=7) c = Color.GREEN;
			else if (i<=9) c = Color.CYAN;
			
			for(int j = 0; j < NBRICKS_PER_ROW; j++){
				GRect brick = new GRect(brickX, brickY, BRICK_WIDTH, BRICK_HEIGHT);
				brickCounter++;
				add(brick);
				brick.setFillColor(c);
				brick.setFilled(true);
				brickX += BRICK_WIDTH+BRICK_SEP;
			}
			brickX = BRICK_X_OFFSET;
			brickY = brickY + BRICK_HEIGHT + BRICK_SEP;
		}
		
		/*Adding and positioning the ball.*/
		setupBall();
	}
	
	/** Adds and positions the ball.*/
	private void setupBall() {
		add(ball, paddle.getX()+(PADDLE_WIDTH/2)-BALL_RADIUS, BALL_Y_MAX);
		ball.setFillColor(Color.BLACK);
		ball.setFilled(true);
		
	}

	/** Sets up the paddle.*/
	private void setupPaddle() {
		add(paddle);
		paddle.setFilled(true);
		paddle.setFillColor(RandomGenerator.getInstance().nextColor());
		paddle.setColor(RandomGenerator.getInstance().nextColor());	
	}
}