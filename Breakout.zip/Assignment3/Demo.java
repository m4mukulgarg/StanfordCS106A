

import acm.program.ConsoleProgram;

/**
 * Demonstration of classes in prelimins package.
 * @author WantedChamp
 */
public class Demo extends ConsoleProgram {
	
	public void run(){
		Student stud = new Student ("Sahami", 204096);
		stud.setUnits(179);
		
		println(stud.getName() + " has "
				+ stud.getUnits() + " units.");
		
		println(stud.getName() + " can graduate: "
				+ stud.hasEnoughUnits());
		
		println(stud.getName() + " takes CS106A!");
		stud.incrementUnits(5);
		
		println(stud.getName() + " can graduate: "
				+ stud.hasEnoughUnits());
				
		if (stud.hasEnoughUnits()){
			println("Rock on " + stud.toString());
		}
		
	}

}
