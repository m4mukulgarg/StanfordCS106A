import java.awt.Color;
import acm.graphics.GOval;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class RandomCircle extends GraphicsProgram {
	public void run(){
		while (true){
			GOval circle;
			for(int i=0; i<10; i++){
				RandomGenerator next = new RandomGenerator();
				int radius = next.nextInt(5,50);
				int x = next.nextInt(0,getWidth()-radius*2);
				int y = next.nextInt(0,getHeight()-radius*2);
				Color color = next.nextColor();
				circle = new GOval(x,y,radius*2,radius*2);
				circle.setFillColor(color);
				circle.setFilled(true);
				add(circle);
				pause(300);
			}
			removeAll();
		}
	}
}
