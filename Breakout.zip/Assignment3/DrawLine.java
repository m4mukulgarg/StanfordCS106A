import acm.program.GraphicsProgram;
import acm.graphics.GLine;
import acm.graphics.GPoint;
import java.awt.event.MouseEvent;

public class DrawLine extends GraphicsProgram {
	public void init(){
		addMouseListeners();
	}
	
	/** This method is called when the mouse is pressed.*/
	public void mousePressed(MouseEvent e){
		startPoint = new GPoint(e.getPoint());
		gline = new GLine(startPoint.getX(),startPoint.getY(),e.getX(),e.getY());
		add(gline);
	}
	
	/** This method is called when the mouse is pressed.*/
	public void mouseDragged(MouseEvent e){
		gline.setEndPoint(e.getX(), e.getY());
	}
	
	/** Private instance variables.*/
	/** Starting point where mouse is pressed.*/
	private GPoint startPoint = null;
	
	private GLine gline = null;
}
